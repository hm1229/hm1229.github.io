# 实验步骤

## 创建 Rust 项目



### 准备

*默认环境全部安装完成*



首次安装Ubuntu后，root用户默认是被**锁定**了的，不允许登录，也不允许 su 到 root ，即表示与root建立一个链接，工作环境不变，通过root执行命令，对于桌面用户来说这个可能是为了增强安全性。

**设置密码**

```shell
$ sudo passwd root
```



### 使用 Cargo 工具来创建一个 Rust 项目

#### Cargo介绍

Cargo是Rust的程序构建和包管理工具，通过在Cargo中声明依赖库，可以下载并编译依赖库，同时Cargo也可以用于整个项目的生命周期，创建、编译、发布。Cargo在安装rust的时候就已经完成了安装，所以不需要单独安装。

#### 使用Cargo创建项目

我们首先创建一个整个项目的目录，并在工作目录中首先创建一个名为 `rust-toolchain` 的文件，并在其中写入所需要的工具链版本：

```
nightly-2021-01-30
```

之后在目录内部使用 `cargo new` 命令在我们的项目目录内创建一个新的 Rust 项目 os，命令如下：

```shell
$ cargo new os
```

[^’cargo new‘ 命令]: 获取项目的名称（os）

> 这里我们把项目命名为 os。同时，cargo 默认为我们添加了 `--bin` 选项，说明我们将要创建一个可执行文件而非一个库。

`--bin` 选项来告诉 Cargo 我们创建一个可执行项目而不是库项目。此时，项目的文件结构如下

```shell
Project                 项目目录
├── rust-toolchain      Rust 工具链版本
└── os
    ├── Cargo.toml      项目配置文件
    └── src             源代码路径
        └── main.rs     源程序
```

`Cargo.toml` 中保存着项目的配置，包括作者的信息、联系方式以及库依赖等等。显而易见源代码保存在 `src` 目录下，目前为止只有 `main.rs` 一个文件

```rust
fn main() {
    println!("Hello, world!");
}
```

### 运行

```shell
$ cargo run
   Compiling os v0.1.0 (/home/liujiaxu/Desktop/learn/ch1/os)
    Finished dev [unoptimized + debuginfo] target(s) in 1.07s
     Running `target/debug/os`
Hello, world!
```

> [^`cargo run` 命令]: ，一步完成 “Hello, world!” 程序的编译和运行
>
> 编程和执行程序的方便性并不是理所当然的，背后有着从硬件 到软件的多种机制的支持。特别是对于应用程序的运行，是需要有一个强大的执行环境来帮助。

## 移除标准库依赖

### 禁用标准库

Rust项目默认是链接标准库 std 的，它依赖于现有的操作系统，因此我们需要显式通过 `#![no_std]` 将其禁用：

> #### Rust 标准库与核心库
>
> 我们尝试一下将当前的 `Hello, world!` 程序的目标平台换成 riscv64gc-unknown-none-elf 看看会发生什么事情：
>
> ```shell
> $ cargo run --target riscv64gc-unknown-none-elf
> Compiling os v0.1.0 (/home/liujiaxu/Desktop/learn/ch1/os)
> error[E0463]: can't find crate for `std`
> |
> = note: the `riscv64gc-unknown-none-elf` target may not be installed
> 
> error: aborting due to previous error
> 
> For more information about this error, try `rustc --explain E0463`.
> error: could not compile `os`.
> ```
>
> 在之前的开发环境配置中，我们已经在 rustup 工具链中安装了这个目标平台支持，因此并**不是**该目标平台未安装的问题。这个问题只是单纯的表示在这个目标平台上找不到 Rust 标准库 std。我们之前曾经提到过，编程语言的标准库或三方库的某些功能会直接或间接的用到操作系统提供的系统调用。但目前我们所选的目标平台不存在任何操作系统支持，于是 Rust 并没有为这个目标平台支持完整的**标准库** std。类似这样的平台通常被我们称为 **裸机平台** (bare-metal)。
>
> > **Rust 语言标准库**
> >
> > Rust 语言标准库是让 Rust 语言开发的软件具备可移植性的基础，类似于 C 语言的 libc 标准库。它是一组最小的、经过实战检验的共享抽象，适用于更广泛的 Rust 生态系统开发。它提供了核心类型，如 Vec 和 Option、类库定义的语言原语操作、标准宏、I/O 和多线程等。默认情况下，所有 Rust crate 都可以使用 std 来支持 Rust 应用程序的开发。但Rust语言标准库的一个限制是，它需要有操作系统的支持。所以，如果你要实现的软件是运行在裸机上的操作系统，就不能直接用Rust语言标准库了。
>
> 幸运的是，Rust 有一个对 std 裁剪过后的核心库 core，这个库是不需要任何操作系统支持的，相对的它的功能也比较受限，但是也包含了 Rust 语言中相当一部分的核心机制，可以满足我们的大部分需求。Rust 语言是一种面向系统（包括操作系统）开发的语言，所以在 Rust 语言生态中，有很多三方库也不依赖标准库 std 而仅仅依赖核心库 core，它们也可以很大程度上减轻我们的编程负担。它们是我们能够在裸机平台挣扎求生的最主要倚仗，也是大部分运行在没有操作系统支持的Rust嵌入式软件的必备。
>
> 于是，我们知道在裸机平台上我们要将对于标准库 std 的引用换成核心库 core。但是做起来其实还要有一些事情需要解决。

```rust
// os/src/main.rs
//! # 全局属性
//! - `#![no_std]`  
//!   禁用标准库
#![no_std]

fn main() {
    println!("Hello, rCore-Tutorial!");
}
```

我们使用 `cargo build` 构建项目，会出现下面三个错误：

```shell
error: cannot find macro `println` in this scope
 --> src/main.rs:3:5
  |
7 |     println!("Hello, rCore-Tutorial!");
  |     ^^^^^^^
error: `#[panic_handler]` function required, but not found
error: language item required, but not found: `eh_personality`
```

接下来，我们依次解决这些问题。

### 宏 println!

第一个错误是说 `println!` 宏未找到，实际上这个宏属于 Rust 标准库 std，它会依赖操作系统标准输出等一系列功能。由于它被我们禁用了当然就找不到了。我们暂时将该输出语句删除，之后给出不依赖操作系统的实现。

### panic 处理函数

在使用 Rust 编写应用程序的时候，我们常常在遇到了一些无法恢复的致命错误导致程序无法继续向下运行的时候手动或自动调用 panic! 宏来打印出一个错误信息，展开并清理栈数据，然后接着退出。出现这种情况的场景通常是检测到一些类型的 bug，而且程序员并不清楚该如何处理它

在标准库 std 中提供了 panic 的处理函数 `#[panic_handler]`，其大致功能是打印出错位置和原因并杀死当前应用。可惜的是在核心库 core 中并没有提供， 因此我们需要添加自己实现的 panic 处理函数。

> **Rust 语法卡片：语义项 lang_items**
>
> Rust 编译器内部的某些功能的实现并不是硬编码在语言内部的，而是以一种可插入的形式在库中提供。库只需要通过某种方式告诉编译器它的某个方法实现了 编译器内部的哪些功能，编译器就会采用库提供的方法来实现它内部对应的功能。通常只需要在库的方法前面加上一个**标记**即可。

```rust
//os/src/main.rs
use core::panic::PanicInfo;

/// 当 panic 发生时会调用该函数
/// 我们暂时将它的实现为一个死循环
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}
```

注意，panic 处理函数的函数签名需要一个 `PanicInfo` 的不可变借用作为输入参数，它在核心库中得以保留，这也是我们第一次与核心库打交道。类型为 `PanicInfo` 的参数包含了 panic 发生的文件名、代码行数和可选的错误信息。

`panic` 这个函数从不返回，所以他被标记为发散函数（Diverging Function）。发散函数的返回类型称作 Never 类型（"never" type），记为 `!`。对这个函数，我们目前能做的很少，所以我们只需编写一个死循环 `loop {}`。

>**函数返回值**
>
>Rust 函数声明返回值类型的方式：在参数声明之后用 **->** 来声明函数返回值的类型。
>
>在函数体中，随时都可以以 return 关键字结束函数运行并返回一个类型合适的值。这也是最接近大多数开发者经验的做法.
>
>但是 Rust 不支持自动返回值类型判断，如果没有明确声明函数返回值的类型，函数将被认为是"纯过程"，不允许产生返回值，return 后面不能有返回值表达式。这样做的目的是为了让公开的函数能够形成可见的公报。
>
>**注意：**函数体表达式并不能等同于函数体，它不能使用 **return** **关键字。**

>**整数型（Integer）**
>
>isize 和 usize 两种整数类型是用来衡量数据大小的，它们的位长度取决于所运行的目标平台，如果是 32 位架构的处理器将使用 32 位位长度整型。
>
>| 位长度  | 有符号 | 无符号 |
>| :------ | :----- | :----- |
>| 8-bit   | i8     | u8     |
>| 16-bit  | i16    | u16    |
>| 32-bit  | i32    | u32    |
>| 64-bit  | i64    | u64    |
>| 128-bit | i128   | u128   |
>| arch    | isize  | usize  |

> **发散函数**
>
> 发散函数（diverging function）是rust中的一个特性。发散函数不返回，它使用感叹号`!`作为返回类型表示。发散函数不具有返回值，所以他可以成为**任何类型**。
>
> 由于发散函数不会返回，所以就算其后再有其他语句也是不会执行的。倘若其后还有其他语句，会出现编译警告。

>**Rust 语言有原生的无限循环结构  loop**
>
>loop 循环可以通过 break 关键字类似于 return 一样使整个循环退出并给予外部一个返回值。这是一个十分巧妙的设计，因为 loop 这样的循环常被用来当作查找工具使用，如果找到了某个东西当然要将这个结果交出去

### eh_personality 语义项

第三个错误提到了语义项（Language Item） ，它是编译器内部所需的特殊函数或类型。刚才的 `panic_handler` 也是一个语义项，我们要用它告诉编译器当程序发生 panic 之后如何处理。

而这个错误相关语义项 `eh_personality` ，其中 eh 是 Exception Handling 的缩写，它是一个标记某函数用来实现**堆栈展开**处理功能的语义项。这个语义项也与 panic 有关。

>  **堆栈展开 (Stack Unwinding)**
>
>  通常当程序出现了异常时，从异常点开始会沿着 caller 调用栈一层一层回溯，直到找到某个函数能够捕获这个异常或终止程序。这个过程称为堆栈展开。
>
>  当程序出现异常时，我们需要沿着调用栈一层层回溯上去回收每个 caller 中定义的局部变量（这里的回收包括 C++ 的 RAII 的析构以及 Rust 的 drop 等）避免造成捕获异常并恢复后的内存溢出。
>
>  而在 Rust 中，panic 证明程序出现了错误，我们则会对于每个 caller 函数调用依次这个被标记为堆栈展开处理函数的函数进行清理。
>
>  这个处理函数是一个依赖于操作系统的复杂过程，在标准库中实现。但是我们禁用了标准库使得编译器找不到该过程的实现函数了。

简单起见，我们这里不会进一步捕获异常也不需要清理现场，我们设置为直接退出程序即可。这样堆栈展开处理函数不会被调用，编译器也就不会去寻找它的实现了。

因此，我们在项目配置文件中直接将 dev 配置和 release 配置的 panic 的处理策略设为直接终止，也就是直接调用我们的 `panic_handler` 而不是先进行堆栈展开等处理再调用：

```toml
#os/Cargo.toml

...		
#在下面添加
# panic 时直接终止，因为我们没有实现堆栈展开的功能
[profile.dev]
panic = "abort"

[profile.release]
panic = "abort"
```

此时，我们 `cargo build` ，但是又出现了新的错误：

```bash
error: requires `start` lang_item
```

## 移除运行时环境依赖

### 运行时系统

对于大多数语言，他们都使用了**运行时系统**（Runtime System），这可能导致 `main` 函数并不是实际执行的第一个函数。

以 Rust 语言为例，一个典型的链接了标准库的 Rust 程序会首先跳转到 C 语言运行时环境中的 `crt0`（C Runtime Zero）进入 C 语言运行时环境设置 C 程序运行所需要的环境（如创建堆栈或设置寄存器参数等）。

然后 C 语言运行时环境会跳转到 Rust 运行时环境的入口点（Entry Point）进入 Rust 运行时入口函数继续设置 Rust 运行环境，而这个 Rust 的运行时入口点就是被 `start` 语义项标记的。Rust 运行时环境的入口点结束之后才会调用 `main` 函数进入主程序。

C 语言运行时环境和 Rust 运行时环境都需要标准库支持，我们的程序无法访问。如果覆盖了 `start` 语义项，仍然需要 `crt0`，并不能解决问题。所以需要重写覆盖整个 `crt0` 入口点：

```rust
//os/src/main.rs
//! # 全局属性
//! - `#![no_std]`  
//!   禁用标准库
#![no_std]
//!
//! - `#![no_main]`  
//!   不使用 `main` 函数等全部 Rust-level 入口点来作为程序入口
#![no_main]

use core::panic::PanicInfo;

/// 当 panic 发生时会调用该函数
/// 我们暂时将它的实现为一个死循环
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}

/// 覆盖 crt0 中的 _start 函数
/// 我们暂时将它的实现为一个死循环
#[no_mangle]
pub extern "C" fn _start() -> ! {
    loop {}
}
```

我们加上 `#![no_main]` 告诉编译器我们不用常规的入口点。

同时我们实现一个 `_start` 函数来代替 `crt0`，并加上 `#[no_mangle]` 告诉编译器对于此函数禁用编译期间的名称重整（Name Mangling），即确保编译器生成一个名为 `_start` 的函数，而非为了实现函数重载等而生成的形如 `_ZN3blog_os4_start7hb173fedf945531caE` 散列化后的函数名。由于 `_start` 是大多数系统的默认入口点名字，所以我们要确保它不会发生变化。

接着，我们使用 `extern "C"` 描述 `_start` 函数，由于 `_start` 是作为 C 语言运行时的入口点，看起来合情合理。

> ### Rust 语法卡片：`extern`
>
> Rust 有一个关键字，`extern`，有助于创建和使用 **外部函数接口**（*Foreign Function Interface*， FFI）。外部函数接口是一个编程语言用以定义函数的方式，其允许不同（外部）编程语言调用这些函数。
>
> `extern` 块中声明的函数在 Rust 代码中总是不安全的。因为其他语言不会强制执行 Rust 的规则且 Rust 无法检查它们，所以确保其安全是程序员的责任
>
> 在 `extern "C"` 块中，列出了我们希望能够调用的另一个语言中的外部函数的签名和名称。`"C"` 部分定义了外部函数所使用的 **应用二进制接口**（*application binary interface*，ABI） —— ABI 定义了如何在汇编语言层面调用此函数。`"C"` ABI 是最常见的，并遵循 C 编程语言的 ABI。

由于程序会一直停在 `crt0` 的入口点，我们可以移除没用的 `main` 函数。

### 链接错误

再次 `cargo build` ，我们会看到一大段链接错误。

链接器（Linker）是一个程序，它将生成的目标文件组合为一个可执行文件。不同的操作系统如 Windows、macOS 或 Linux，规定了不同的可执行文件格式，因此也各有自己的链接器，抛出不同的错误；但这些错误的根本原因还是相同的：链接器的默认配置假定程序依赖于 C 语言的运行时环境，但我们的程序并不依赖于它。

为了解决这个错误，我们需要告诉链接器，它不应该包含 C 语言运行时环境。我们可以选择提供特定的链接器参数（Linker Argument），也可以选择编译为裸机目标（Bare Metal Target），我们将沿着后者的思路在后面解决这个问题，即直接编译为裸机目标不链接任何运行时环境。

在默认情况下，Rust 尝试适配当前的系统环境，编译可执行程序。举个例子，如果你使用 x86_64 平台的 Windows 系统，Rust 将尝试编译一个扩展名为 `.exe` 的 Windows 可执行程序，并使用 `x86_64` 指令集。这个环境又被称作为你的宿主系统（Host System）。

为了描述不同的环境，Rust 使用一个称为目标三元组（Target Triple）的字符串 `<arch><sub>-<vendor>-<sys>-<abi>`。要查看当前系统的目标三元组，我们可以运行 `rustc --version --verbose`：

> #### **目标三元组** (Target Triplet) 
>
> 我们可以通过 **目标三元组** (Target Triplet) 来描述一个目标平台。它一般包括 CPU 架构、CPU 厂商、操作系统和运行时库，它们确实都会控制目标文件的生成。
>
> **CPU架构**：CPU厂商给属于同一系列的CPU产品定的一个规范，主要目的是为了区分不同类型CPU的重要标示。
>
> **运行时库**：运行时库是一种被编译器用来实现编程语言内置函数，以提供该语言程序运行时(执行)支持的一种特殊的计算机程序库。这种库一般包括基本的输入输出或是内存管理等支持。
>
> 比如，我们可以尝试看一下之前的 `Hello, world!` 的目标平台是什么。这可以通过打印编译器 rustc 的默认配置信息：
>
> ```shell
> $ rustc --version --verbose
> rustc 1.43.0
> binary: rustc
> commit-hash: unknown
> commit-date: unknown
> host: x86_64-unknown-linux-gnu
> release: 1.43.0
> LLVM version: 9.0
> ```
>
> 上面这段输出来自一个 x86_64 平台下的 Linux 系统。我们能看到，host 字段的值为三元组 x86_64-unknown-linux-gnu，它包含了 CPU 架构 x86_64、供应商 unknown、操作系统 linux 和二进制接口 gnu（封装了Linux系统调用，并提供POSIX接口为主的函数库）。

Rust 编译器尝试为当前系统的三元组编译，并假定底层有一个类似于 Windows 或 Linux 的操作系统提供 C 语言运行环境，然而这将导致链接器错误。所以，为了避免这个错误，我们可以另选一个底层没有操作系统的运行环境。

这样的运行环境被称作裸机环境，例如目标三元组 riscv64imac-unknown-none-elf 描述了一个 RISC-V 64 位指令集的系统。我们暂时不需要了解它的细节，只需要知道这个环境底层没有操作系统，这是由三元组中的 none 描述的。要为这个目标编译，我们需要使用 rustup 添加它：

```bash
rustup target add riscv64gc-unknown-none-elf
```

这行命令将为目标下载一个标准库和 core 库。这之后，我们就能为这个目标成功构建独立式可执行程序了：

```bash
cargo build --target riscv64gc-unknown-none-elf
```

此时，我们已经可以编译成功了

> 我们选择的是 riscv64gc-unknown-none-elf，目标三元组中的**CPU 架构**是 riscv64gc，**厂商**是 unknown，**操作系统**是 none，elf表示没有标准的运行时库（表明没有任何系统调用的封装支持），但可以生成ELF格式的执行程序。这里我们之所以不选择有 linux-gnu 系统调用支持的版本 riscv64gc-unknown-linux-gnu，是因为我们只是想跑一个 Hello, world!，没有必要使用操作系统所提供的 那么高级的抽象。而且我们很清楚后续我们要开发的是一个操作系统内核，它必须直面底层物理硬件（bare-metal）来提供更大的操作系统服务功能，已有操作系统（如Linux）提供的系统调用服务对这个内核而言是多余的。

> #### RISC-V 指令集拓展
>
> 由于基于 RISC-V 架构的处理器可能用于嵌入式场景或是通用计算场景，因此指令集规范将指令集划分为最基本的 RV32/64I 以及若干标准指令集拓展。 每款处理器只需按照其实际应用场景按需实现指令集拓展即可。
>
> - RV32/64I：每款处理器都必须实现的基本整数指令集。在 RV32I 中，每个通用寄存器的位宽为 32 位；在 RV64I 中则为 64 位。它可以用来模拟 绝大多数标准指令集拓展中的指令，除了比较特殊的 A 拓展，因为它需要特别的硬件支持。
> - M 拓展：提供整数乘除法相关指令。
> - A 拓展：提供原子指令和一些相关的内存同步机制，这个后面会展开。
> - F/D 拓展：提供单/双精度浮点数运算支持。
> - C 拓展：提供压缩指令拓展。
>
> G 拓展是基本整数指令集 I 再加上标准指令集拓展 MAFD 的总称，因此 riscv64gc 也就等同于 riscv64imafdc。我们剩下的内容都基于该处理器 架构完成。除此之外 RISC-V 架构还有很多标准指令集拓展，有一些还在持续更新中尚未稳定，有兴趣的读者可以浏览最新版的 RISC-V 指令集规范。

编译出的结果被放在了 `os/target/riscv64imac-unknown-none-elf/debug` 文件夹中。可以看到其中有一个名为 `os` 的可执行文件。不过由于它的目标平台是 RISC-V 64，我们暂时还不能通过我们的开发环境执行它。

由于我们之后都会使用 RISC-V 作为编译目标，为了避免每次都要加 `--target` 参数，我们可以使用 [cargo 配置文件](https://doc.rust-lang.org/cargo/reference/config.html)为项目配置默认的编译选项。

在 `os` 文件夹中创建一个 `.cargo` 文件夹，并在其中创建一个名为 `config` 的文件，在其中填入以下内容：

```toml
#os/.cargo/config
# 编译的目标平台
[build]
target = "riscv64gc-unknown-none-elf"
```

这指定了此项目编译时默认的目标。以后我们就可以直接使用 `cargo build` 来编译了。

至此，我们完成了在 RISC-V 64 位平台的二进制程序编译，后面我们将通过布局和代码的简单调整实现一个最简单的内核。

### 安装 binutils 工具集

为了查看和分析生成的可执行文件，我们首先需要安装一套名为 binutils 的命令行工具集，其中包含了 objdump 和 objcopy 等常用工具。

Rust 社区提供了一个 cargo-binutils 项目，可以帮助我们方便地调用 Rust 内置的 LLVM binutils。我们用以下命令安装它：

```bash
$ cargo install cargo-binutils
$ rustup component add llvm-tools-preview
```

之后尝试使用 `rust-objdump --version` 命令看看是否安装成功。

### 查看生成的可执行文件

在上一节中我们自己实现了一套运行时来代替标准库，并完整的构建了最终的可执行文件。但是它现在只是放在磁盘上的一个文件，若想将它运行起来的话， 就需要将它加载到内存中，在大多数情况下这是操作系统的任务。

我们编译之后的产物为 `os/target/riscv64gc-unknown-none-elf/debug/os`，让我们先看看它的文件类型：

```shell
$ file target/riscv64gc-unknown-none-elf/debug/os
target/riscv64gc-unknown-none-elf/release/os: ELF 64-bit LSB executable, UCB RISC-V, version 1 (SYSV), statically linked, not stripped
```

从中可以看出可执行文件的格式为 **可执行和链接格式** (Executable and Linkable Format, **ELF**)，硬件平台是 RV64 。在 ELF 文件中， 除了程序必要的代码、数据段（它们本身都只是一些二进制的数据）之外，还有一些 **元数据** (Metadata) 描述这些段在地址空间中的位置和在 文件中的位置以及一些权限控制信息，这些元数据只能放在代码、数据段的外面。链接方式为静态链接；not stripped 指的是里面符号表的信息未被剔除，而这些信息在调试程序时会用到，程序正常执行时通常不会使用。

我们可以通过二进制工具 `readelf` 来看看 ELF 文件中究竟包含什么内容，输入命令：

#### 使用体系结构提供的工具

```shell
$ sudo apt install binutils-riscv64-unknown-elf
$ riscv64-unknown-elf-readelf target/riscv64gc-unknown-none-elf/debug/os -a
```

首先可以看到一个 ELF header，它位于 ELF 文件的开头：

```none
ELF Header:
> Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI Version:                       0
  Type:                              EXEC (Executable file)
  Machine:                           RISC-V
  Version:                           0x1
  Entry point address:               0x80020000
> Start of program headers:          64 (bytes into file)
> Start of section headers:          9016 (bytes into file)
  Flags:                             0x1, RVC, soft-float ABI
  Size of this header:               64 (bytes)
  Size of program headers:           56 (bytes)
> Number of program headers:         3
  Size of section headers:           64 (bytes)
> Number of section headers:         8
  Section header string table index: 6
```

- 第 2 行（Magic）是一个称之为 **魔数** (Magic) 独特的常数，存放在 ELF header 的一个固定位置。当加载器将 ELF 文件加载到内存之前，通常会查看 该位置的值是否正确，来快速确认被加载的文件是不是一个 ELF 。
- 第 11 行（Entry point address）给出了可执行文件的入口点为 `0x80020000` ，这正是我们上一节所做的事情。
- 从 12/13/17/19 （Start of program headers / Start of section headers / Number of program headers / Number of section headers）行中，我们可以知道除了 ELF header 之外，还有另外两种不同的 header，分别称为 program header 和 section header， 它们都有多个。ELF header 中给出了三种 header 的大小、在文件中的位置以及数目。

一共有 3 个不同的 program header，它们从文件的 64 字节开始，每个 56 字节：

```
Program Headers:
  Type           Offset             VirtAddr           PhysAddr
                 FileSiz            MemSiz              Flags  Align
  LOAD           0x0000000000001000 0x0000000080020000 0x0000000080020000
                 0x000000000000001a 0x000000000000001a  R E    0x1000
  LOAD           0x0000000000002000 0x0000000080021000 0x0000000080021000
                 0x0000000000000000 0x0000000000010000  RW     0x1000
  GNU_STACK      0x0000000000000000 0x0000000000000000 0x0000000000000000
                 0x0000000000000000 0x0000000000000000  RW     0x0
```

每个 program header 指向一个在加载的时候可以连续加载的区域。

一共有 8 个不同的 section header，它们从文件的 9016 字节开始，每个 64 字节：

```
Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [ 0]                   NULL             0000000000000000  00000000
       0000000000000000  0000000000000000           0     0     0
  [ 1] .text             PROGBITS         0000000080020000  00001000
       000000000000001a  0000000000000000  AX       0     0     2
  [ 2] .bss              NOBITS           0000000080021000  00002000
       0000000000010000  0000000000000000  WA       0     0     1
  [ 3] .riscv.attributes RISCV_ATTRIBUTE  0000000000000000  00002000
       000000000000006a  0000000000000000           0     0     1
  [ 4] .comment          PROGBITS         0000000000000000  0000206a
       0000000000000013  0000000000000001  MS       0     0     1
  [ 5] .symtab           SYMTAB           0000000000000000  00002080
       00000000000001c8  0000000000000018           7     4     8
  [ 6] .shstrtab         STRTAB           0000000000000000  00002248
       0000000000000041  0000000000000000           0     0     1
  [ 7] .strtab           STRTAB           0000000000000000  00002289
       00000000000000ab  0000000000000000           0     0     1
Key to Flags:
  W (write), A (alloc), X (execute), M (merge), S (strings), I (info),
  L (link order), O (extra OS processing required), G (group), T (TLS),
  C (compressed), x (unknown), o (OS specific), E (exclude),
  p (processor specific)

There are no section groups in this file.
```

每个 section header 则描述一个段的元数据。

其中，我们看到了代码段 `.text` 被放在可执行文件的 4096 字节处，大小 0x1a=26 字节，需要被加载到地址 `0x80020000`。 它们分别由元数据的字段 Offset、 Size 和 Address 给出。同理，我们自己预留的应用程序函数调用栈在 `.bss` 段中，大小为 64KiB ，需要被加载到地址 `0x80021000` 处。我们没有看到 `.data/.rodata` 等段，因为目前的 `rust_main` 里面没有任何东西。

我们还能够看到 `.symtab` 段中给出的符号表：

```
Symbol table '.symtab' contains 19 entries:
   Num:    Value          Size Type    Bind   Vis      Ndx Name
     0: 0000000000000000     0 NOTYPE  LOCAL  DEFAULT  UND 
     1: 0000000000000000     0 FILE    LOCAL  DEFAULT  ABS os.78wp4f2l-cgu.0
     2: 0000000000000000     0 FILE    LOCAL  DEFAULT  ABS os.78wp4f2l-cgu.1
     3: 0000000080020000     0 NOTYPE  LOCAL  DEFAULT    1 .Lpcrel_hi0
     4: 0000000080020000     0 NOTYPE  GLOBAL DEFAULT    1 _start
     5: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    2 boot_stack
     6: 0000000080031000     0 NOTYPE  GLOBAL DEFAULT    2 boot_stack_top
     7: 0000000080020010    10 FUNC    GLOBAL DEFAULT    1 rust_main
     8: 0000000080020000     0 NOTYPE  GLOBAL DEFAULT  ABS BASE_ADDRESS
     9: 0000000080020000     0 NOTYPE  GLOBAL DEFAULT    1 skernel
    10: 0000000080020000     0 NOTYPE  GLOBAL DEFAULT    1 stext
    11: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    1 etext
    12: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    1 srodata
    13: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    1 erodata
    14: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    1 sdata
    15: 0000000080021000     0 NOTYPE  GLOBAL DEFAULT    1 edata
    16: 0000000080031000     0 NOTYPE  GLOBAL DEFAULT    2 sbss
    17: 0000000080031000     0 NOTYPE  GLOBAL DEFAULT    2 ebss
    18: 0000000080031000     0 NOTYPE  GLOBAL DEFAULT    2 ekernel
```

里面包括了栈顶、栈底、rust_main 的地址以及我们在 `linker.ld` 中定义的各个段开始和结束地址。

因此，从 ELF header 中可以看出，ELF 中的内容按顺序应该是：

- ELF header
- 若干个 program header
- 程序各个段的实际数据
- 若干的 section header

当将程序加载到内存的时候，对于每个 program header 所指向的区域，我们需要将对应的数据从文件复制到内存中。这就需要解析 ELF 的元数据 才能知道数据在文件中的位置以及即将被加载到内存中的位置。但目前，我们不需要从 ELF 中解析元数据就知道程序的内存布局 （这个内存布局是我们按照需求自己指定的），我们可以手动完成加载任务。

具体的做法是利用 `rust-objcopy` 工具删除掉 ELF 文件中的 所有 header 只保留各个段的实际数据得到一个没有任何符号的纯二进制镜像文件 (<font color=red> **为什么没有符号** </font>: objcopy 进行了压缩) ，由于缺少了必要的元数据，我们的二进制工具也没有办法 对它完成解析了。

> **objcopy**
>
> GNU使用工具程序objcopy作用是拷贝一个目标文件的内容到另一个目标文件中，也就是说，可以将一种格式的目标文件转换成另一种格式的目标文件. 通过使用binary作为输出目标(-o binary)，可产生一个原始的二进制文件，实质上是将所有的符号和重定位信息都将被抛弃，只剩下二进制数据。



#### 使用rust 语言包提供的工具

```bash
$ rust-objdump target/riscv64gc-unknown-none-elf/debug/os -x --arch-name=riscv64

target/riscv64imac-unknown-none-elf/debug/os:    file format ELF64-riscv

architecture: riscv64
start address: 0x0000000000011000

Sections:
Idx Name          Size     VMA          Type
  0               00000000 0000000000000000
  1 .text         0000000c 0000000000011000 TEXT
  2 .debug_str    000004f6 0000000000000000
  3 .debug_abbrev 0000010e 0000000000000000
  4 .debug_info   00000633 0000000000000000
  5 .debug_aranges 00000040 0000000000000000
  6 .debug_ranges 00000030 0000000000000000
  7 .debug_macinfo 00000001 0000000000000000
  8 .debug_pubnames 000000ce 0000000000000000
  9 .debug_pubtypes 000003a2 0000000000000000
 10 .debug_frame  00000068 0000000000000000
 11 .debug_line   00000059 0000000000000000
 12 .comment      00000012 0000000000000000
 13 .symtab       00000108 0000000000000000
 14 .shstrtab     000000b4 0000000000000000
 15 .strtab       0000002d 0000000000000000

SYMBOL TABLE:
0000000000000000 l    df *ABS*    00000000 3k1zkxjipadm3tm5
0000000000000000         .debug_frame    00000000
0000000000011000         .text    00000000
0000000000011000         .text    00000000
0000000000011000         .text    00000000
000000000001100c         .text    00000000
0000000000000000         .debug_ranges    00000000
0000000000000000         .debug_info    00000000
0000000000000000         .debug_line    00000000 .Lline_table_start0
0000000000011000 g     F .text    0000000c _start
Program Header:
    PHDR off    0x0000000000000040 vaddr 0x0000000000010040 paddr 0x0000000000010040 align 2**3
         filesz 0x00000000000000e0 memsz 0x00000000000000e0 flags r--
    LOAD off    0x0000000000000000 vaddr 0x0000000000010000 paddr 0x0000000000010000 align 2**12
         filesz 0x0000000000000120 memsz 0x0000000000000120 flags r--
    LOAD off    0x0000000000001000 vaddr 0x0000000000011000 paddr 0x0000000000011000 align 2**12
         filesz 0x0000000000001000 memsz 0x0000000000001000 flags r-x
   STACK off    0x0000000000000000 vaddr 0x0000000000000000 paddr 0x0000000000000000 align 2**64
         filesz 0x0000000000000000 memsz 0x0000000000000000 flags rw-

Dynamic Section:
```

我们按顺序逐个查看：

- start address：程序的入口地址
- Sections：从这里我们可以看到程序各段的各种信息。后面以 debug 开头的段是调试信息
- SYMBOL TABLE：符号表，从中我们可以看到程序中所有符号的地址。例如 `_start` 函数就位于入口地址上
- Program Header：程序加载时所需的段信息
  - 其中的 off 是它在文件中的位置，vaddr 和 paddr 是要加载到的虚拟地址和物理地址，align 规定了地址的对齐，filesz 和 memsz 分别表示它在文件和内存中的大小，flags 描述了相关权限（r 表示可读，w 表示可写，x 表示可执行）

在这里我们使用的是 `-x` 来查看程序的元信息，下面我们用 `-d` 来对代码进行反汇编：

```bash
$ rust-objdump target/riscv64gc-unknown-none-elf/debug/os -d --arch-name=riscv64

target/riscv64gc-unknown-none-elf/debug/os:    file format ELF64-riscv

Disassembly of section .text:

0000000000011000 _start:
   11000: 41 11                            addi    sp, sp, -16
   11002: 06 e4                            sd    ra, 8(sp)
   11004: 22 e0                            sd    s0, 0(sp)
   11006: 00 08                            addi    s0, sp, 16
   11008: 09 a0                            j    2
   1100a: 01 a0                            j    0
```

可以看到其中只有一个 `_start` 函数，里面什么都不做，就一个死循环。

### 生成内核镜像的操作

我们之前生成的 elf 格式可执行文件有以下特点：

- 含有冗余的调试信息，使得程序体积较大
- 需要对 Program Header 部分进行手动解析才能知道各段的信息，而这需要我们了解 Program Header 的二进制格式，并以字节为单位进行解析

由于我们目前没有调试的手段，不需要调试信息；同时也不会解析 elf 格式文件，所以我们可以使用工具 rust-objcopy 从 elf 格式可执行文件生成内核镜像：

```shell
$ rust-objcopy target/riscv64gc-unknown-none-elf/debug/os --strip-all -O binary target/riscv64gc-unknown-none-elf/debug/kernel.bin
```

这里 `--strip-all` 表明丢弃所有符号表及调试信息，`-O binary` 表示输出为二进制文件。

至此，我们编译并生成了内核镜像 `kernel.bin` 文件。接下来，我们将使用 QEMU 模拟器真正将我们的内核镜像跑起来。不过在此之前还需要完成两个工作：**调整内存布局**和**重写入口函数**。

### 调整内存布局

上一节中我们看到，编译出的程序默认被放到了从 0x11000 开始的位置上：

```clike
start address: 0x0000000000011000
...
Program Header:
    PHDR off    0x0000000000000040 vaddr 0x0000000000010040 ...
    LOAD off    0x0000000000000000 vaddr 0x0000000000010000 ...
    LOAD off    0x0000000000001000 vaddr 0x0000000000011000 ...
   STACK off    0x0000000000000000 vaddr 0x0000000000000000 ...
```

### 编写链接脚本

创建文件 `os/src/linker.ld`：

```
/* os/src/linker.ld */
/* 有关 Linker Script 可以参考：https://sourceware.org/binutils/docs/ld/Scripts.html */

/* 目标架构 */
OUTPUT_ARCH(riscv)

/* 执行入口 */
ENTRY(_start)

/* 数据存放起始地址 */
BASE_ADDRESS = 0x80200000;

SECTIONS
{
    /* . 表示当前地址（location counter） */
    /* . 会随着内存分配改变自己的值，永远指向当前地址 */
    . = BASE_ADDRESS;

    /* start 符号表示全部的开始位置 */
    kernel_start = .;

    text_start = .;

    /* .text 字段 */
    .text : {
        /* 把 entry 函数放在最前面 */
        *(.text.entry)
        /* 要链接的文件的 .text 字段集中放在这里 */
        *(.text .text.*)
    }

    rodata_start = .;

    /* .rodata 字段 */
    .rodata : {
        /* 要链接的文件的 .rodata 字段集中放在这里 */
        *(.rodata .rodata.*)
    }

    data_start = .;

    /* .data 字段 */
    .data : {
        /* 要链接的文件的 .data 字段集中放在这里 */
        *(.data .data.*)
    }

    bss_start = .;

    /* .bss 字段 */
    .bss : {
        /* 要链接的文件的 .bss 字段集中放在这里 */
        *(.sbss .bss .bss.*)
    }

    /* 结束地址 */
    kernel_end = .;
}
```

时至今日我们已经不太可能将所有代码都写在一个文件里面。在编译过程中，我们的编译器和链接器已经给每个文件都自动生成了一个内存布局。这里，我们的链接工具所要做的是最终将各个文件的内存布局装配起来生成整个内核的内存布局。

我们首先使用 OUTPUT_ARCH 指定了架构，随后使用 ENTRY 指定了入口点为 `_start` 函数，即程序第一条被执行的指令所在之处。在这个链接脚本中我们并未看到 `_start` ，回忆上一章，我们为了移除运行时环境依赖，重写了入口 `_start` 。所以，链接脚本宣布整个程序会从那里开始运行。

链接脚本的整体写在 `SECTION{ }` 中，里面有多个形如 `output section: { input section list }` 的语句，每个都描述了整个程序内存布局中的一个输出段 output section 是由各个文件中的哪些输入段 input section 组成的。

我们可以用 `*( )` 来表示将各个文件中所有符合括号内要求的输入段放在当前的位置。而括号内，你可以直接使用段的名字，也可以包含通配符 `*`。

单独的一个 `.` 为**当前地址（Location Counter）**，可以对其赋值来从设置的地址继续向高地址放置各个段。如果不进行赋值的话，则默认各个段会紧挨着向高地址放置。将一个符号赋值为 `.` 则会记录下这个符号的地址。

到这里我们大概看懂了这个链接脚本在做些什么事情。首先是从 BASE_ADDRESS 即 0x80200000 开始向下放置各个段，依次是 .text，.rodata，.data，.stack 和 .bss。同时我们还记录下了每个段的开头和结尾地址，如 .text 段的开头、结尾地址分别就是符号 stext 和 etext 的值，我们接下来会用到。

>  **为什么是 0x80200000**
>
>  [OpenSBI](https://github.com/riscv/opensbi)（如想进一步了解，可参看本章的[重写程序入口点](https://rcore-os.github.io/rCore-Tutorial-deploy/docs/lab-0/guide/part7.md)小节相关的介绍）将自身放在 0x80000000，完成初始化后会跳转到 0x80200000，因此 `_start` 必须位于这个地址。.text 为代码段标识，其第一个放置的就是 `_start`（即 `.text.entry`）。

这里面有一个输入段与其他的不太一样，即 .text.entry，似乎编译器不会自动生成这样名字的段。事实上，它是我们在后面自己定义的。

### 使用链接脚本

为了在编译时使用上面自定义的链接脚本，我们在 `.cargo/config` 文件中加入以下配置：

```toml
#os/.cargo/config
# 使用我们的 linker script 来进行链接
[target.riscv64gc-unknown-none-elf]
rustflags = [
    "-C", "link-arg=-Tsrc/linker.ld",
]
```

它的作用是在链接时传入一个参数 `-T` 来指定使用哪个链接脚本。

此时程序已经被正确地放在了指定的地址上。

到这里，我们清楚了最终程序的内存布局会长成什么样子。下一节我们来补充这个链接脚本中未定义的段，并完成编译。

## 重写程序入口点 `_start`

我们在第一章中，曾自己重写了一个入口点 `_start`，在那里我们仅仅只是让它死循环。但是现在，类似 C 语言运行时环境，我们希望这个函数可以为我们设置内核的运行环境。随后，我们才真正开始执行内核的代码。

但是具体而言我们需要设置怎样的运行环境呢？

我们在上一小节提到过，一个应用程序的运行离不开下面多层执行环境栈的支撑。以 `Hello, world!` 程序为例，在目前广泛使用的操作系统上， 它就至少需要经历以下层层递进的初始化过程：

- **启动OS**：硬件启动后，会有一段代码（一般统称为bootloader）对硬件进行初始化，让包括内核在内的系统软件得以运行；
- **OS准备好应用程序执行的环境**：要运行该应用程序的时候，内核分配相应资源，将程序代码和数据载入内存，并赋予 CPU 使用权，由此应用程序可以运行；
- **应用程序开始执行**：程序员编写的代码是应用程序的一部分，它需要标准库/核心库进行一些初始化工作后才能运行。

不过我们的目标是实现在裸机上执行的应用。 在上一小节中，由于目标平台 `riscv64gc-unknown-none-elf` 没有任何操作系统支持，我们只能禁用标准库并移除默认的 main 函数 入口。但是最终我们还是要将 main 函数恢复回来并且输出 `Hello, world!` 的。因此，我们需要知道具体需要做哪些初始化工作才能支持 应用程序在裸机上的运行。

>  **第一条指令**
>
>  在 CPU 加电或 Reset 后，它首先会进行自检（POST, Power-On Self-Test），通过自检后会跳转到**启动代码（Bootloader）**的入口。在 bootloader 中，我们进行外设探测，并对内核的运行环境进行初步设置。随后，bootloader 会将内核代码从硬盘加载到内存中，并跳转到内核入口，正式进入内核。也就是说，CPU 所执行的第一条指令其实是指 bootloader 的第一条指令

幸运的是， 我们已经有现成的 bootloader 实现 [OpenSBI](https://github.com/riscv/opensbi) 固件（Firmware）。

> **Firmware 固件**
>
> 在计算中，固件是一种特定的计算机软件，它为设备的特定硬件提供低级控制进一步加载其他软件的功能。固件可以为设备更复杂的软件（如操作系统）提供标准化的操作环境，或者，对于不太复杂的设备，充当设备的完整操作系统，执行所有控制、监视和数据操作功能。在基于 x86 的计算机系统中, BIOS 或 UEFI 是一种固件；在基于 RISC-V 的计算机系统中，OpenSBI 是一种固件。

OpenSBI 固件运行在特权级别很高的计算机硬件环境中，即 RISC-V 64 的 M Mode（CPU 加电后也就运行在 M Mode），我们将要实现的 OS 内核运行在 S Mode，而我们要支持的用户程序运行在 U Mode。在开发过程中我们重点关注 S Mode。

> **RISC-V 64 的特权级**
>
> RISC-V 共有 4种特权级，分别是 U Mode（User / Application 模式）、S Mode（Supervisor 模式）、H Mode（Hypervisor 模式）（可以没有）和 M Mode（Machine 模式）。
>
> 从 U 到 S 再到 M，权限不断提高，这意味着你可以使用更多的特权指令，访需求权限更高的寄存器等等。我们可以使用一些指令来修改 CPU 的**当前特权级**。而当当前特权级不足以执行特权指令或访问一些寄存器时，CPU 会通过某种方式告诉我们。

OpenSBI 所做的一件事情就是把 CPU 从 M Mode 切换到 S Mode，接着跳转到一个固定地址 0x80200000，开始执行内核代码。

>  **RISC-V 的 M Mode**
>
>  机器模式（缩写为 M 模式，M-mode）是 RISC-V 中 hart（hardware thread，硬件线程）可以执行的最高权限模式。在 M 模式下运行的 hart 对内存，I/O 和一些对于启动和配 置系统来说必要的底层功能有着完全的使用权。因此它是唯一所有标准 RISC-V 处理器都 必须实现的权限模式。
>
>  **RISC-V 的 S Mode**
>
>  Supervisor 模式是一种可选的权限模式，旨在支持现代类 Unix 操作系统（如 Linux，FreeBSD 和 Windows）。S 模式比 U 模式权限更高，但比 M 模式低。与 U 模式一样，S 模式下运行的软件不能使用 M 模式的 CSR 和指令，支持现代类 Unix 操作系统所需要的基于页面的虚拟内存机制是其核心。

接着我们要在 `_start` 中设置内核的运行环境了，我们直接来看代码：

```assembly
# os/src/entry.asm
# 操作系统启动时所需的指令以及字段
#
# 我们在 linker.ld 中将程序入口设置为了 _start，因此在这里我们将填充这个标签
# 它将会执行一些必要操作，然后跳转至我们用 rust 编写的入口函数
#
# 关于 RISC-V 下的汇编语言，可以参考 https://github.com/riscv/riscv-asm-manual/blob/master/riscv-asm.md

    .section .text.entry
    .globl _start
# 目前 _start 的功能：将预留的栈空间写入 $sp，然后跳转至 rust_main
_start:
    la sp, boot_stack_top
    call rust_main

    # 回忆：bss 段是 ELF 文件中只记录长度，而全部初始化为 0 的一段内存空间
    # 这里声明字段 .bss.stack 作为操作系统启动时的栈
    .section .bss.stack
    .global boot_stack
boot_stack:
    # 16K 启动栈大小
    .space 4096 * 16
    .global boot_stack_top
boot_stack_top:
    # 栈结尾
```

可以看到我们在 .bss 中加入了 .stack 段，并在这里分配了一块 4096×4 Bytes=16 KBytes 的内存作为启动时内核的栈。之前的 .text.entry 也出现了，也就是我们将 `_start` 函数放在了 .text 段的开头。

从第 2 行开始，我们通过汇编代码实现执行环境的初始化，它其实只有两条指令：第一条指令 `la sp, boot_stack_top` 将 sp 设置为我们预留的栈空间的栈顶位置，于是之后在函数调用的时候，栈就可以从这里开始向低地址增长了。简单起见，我们目前暂时不考虑 sp 越过了栈底 `boot_stack` ，也就是栈溢出的情形，虽然这有 可能导致严重的错误。第二条指令 `call rust_main` 则是通过伪指令 `call` 函数调用 `rust_main` ，这里的 `rust_main` 是一个我们稍后自己编写的应用 入口。因此初始化任务非常简单：正如上面所说的一样，只需要设置栈指针 sp，随后跳转到应用入口即可。这两条指令单独作为一个名为 `.text.entry` 的段，且全局符号 `_start` 给出了段内第一条指令的地址。

在这段汇编代码中，我们在 .bss 中加入了 .stack 段，并在这里分配了一块 4096×4 Bytes=16 KBytes 的内存作为启动时内核的栈。之前的 .text.entry 也出现了，也就是我们将 `_start` 函数放在了 .text 段的开头。 这块栈空间的栈顶地址被全局符号 `boot_stack_top` 标识，栈底则被全局符号 `boot_stack` 标识。同时，这块栈空间单独作为一个名为 `.bss.stack` 的段，之前我们已经通过链接脚本来安排它的位置。

我们看看 `_start` 里面做了什么：

1. 修改栈指针寄存器 `sp` 为 .bss.stack 段的结束地址，由于栈是从高地址往低地址增长，所以高地址是初始的栈顶；
2. 使用 `call` 指令跳转到 `rust_main` 。这意味着我们的内核运行环境设置完成了，正式进入内核。

我们将 `os/src/main.rs` 里面的 `_start` 函数删除，并换成 `rust_main` ：

```rust
//os/src/main.rs
//! # 全局属性
//! - `#![no_std]`  
//!   禁用标准库
#![no_std]
//!
//! - `#![no_main]`  
//!   不使用 `main` 函数等全部 Rust-level 入口点来作为程序入口
#![no_main]
//!
//! - `#![feature(global_asm)]`  
//!   内嵌整个汇编文件
#![feature(global_asm)]

// 汇编编写的程序入口，具体见该文件
global_asm!(include_str!("entry.asm"));

use core::panic::PanicInfo;

/// 当 panic 发生时会调用该函数
/// 我们暂时将它的实现为一个死循环
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}

/// Rust 的入口函数
///
/// 在 `_start` 为我们进行了一系列准备之后，这是第一个被调用的 Rust 函数
#[no_mangle]
pub extern "C" fn rust_main() -> ! {
    loop {}
}
```

到现在为止我们终于将一切都准备好了，接下来就要配合 OpenSBI 运行我们的内核！

## 使用 QEMU 运行内核

### 使用 OpenSBI

新版 QEMU 中内置了 OpenSBI 固件，它主要负责在操作系统运行前的硬件初始化和加载操作系统的功能。我们使用以下命令尝试运行一下：

```bash
$ qemu-system-riscv64 \
  --machine virt \
  --nographic \
  --bios default

OpenSBI v0.6
   ____                    _____ ____ _____
  / __ \                  / ____|  _ \_   _|
 | |  | |_ __   ___ _ __ | (___ | |_) || |
 | |  | | '_ \ / _ \ '_ \ \___ \|  _ < | |
 | |__| | |_) |  __/ | | |____) | |_) || |_
  \____/| .__/ \___|_| |_|_____/|____/_____|
        | |
        |_|

Platform Name          : QEMU Virt Machine
Platform HART Features : RV64ACDFIMSU
Platform Max HARTs     : 8
Current Hart           : 0
Firmware Base          : 0x80000000
Firmware Size          : 120 KB
Runtime SBI Version    : 0.2

MIDELEG : 0x0000000000000222
MEDELEG : 0x000000000000b109
PMP0    : 0x0000000080000000-0x000000008001ffff (A)
PMP1    : 0x0000000000000000-0xffffffffffffffff (A,R,W,X)
```

可以看到我们已经在 qemu-system-riscv64 模拟的 QEMU Virt Machine 硬件上将 OpenSBI 这个固件跑起来了。QEMU 可以使用 `ctrl+a` （macOS 为 `control+a`） 再按下 `x` 键退出。

### 加载内核镜像

为了确信我们已经跑起来了内核里面的代码，我们最好在 `rust_main` 里面加上简单的输出：

```rust
//os/src/main.rs
//! # 全局属性
//! - `#![no_std]`  
//!   禁用标准库
#![no_std]
//!
//! - `#![no_main]`  
//!   不使用 `main` 函数等全部 Rust-level 入口点来作为程序入口
#![no_main]
//! # 一些 unstable 的功能需要在 crate 层级声明后才可以使用
//! - `#![feature(llvm_asm)]`  
//!   内嵌汇编
#![feature(llvm_asm)]
//!
//! - `#![feature(global_asm)]`
//!   内嵌整个汇编文件
#![feature(global_asm)]

// 汇编编写的程序入口，具体见该文件
global_asm!(include_str!("entry.asm"));

use core::panic::PanicInfo;

/// 当 panic 发生时会调用该函数
/// 我们暂时将它的实现为一个死循环
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}

/// 在屏幕上输出一个字符
pub fn console_putchar(ch: u8) {
    let _ret: usize;
    let arg0: usize = ch as usize;
    let arg1: usize = 0;
    let arg2: usize = 0;
    let which: usize = 1;
    unsafe {
        llvm_asm!("ecall"
             : "={x10}" (_ret)
             : "{x10}" (arg0), "{x11}" (arg1), "{x12}" (arg2), "{x17}" (which)
             : "memory"
             : "volatile"
        );
    }
}

/// Rust 的入口函数
///
/// 在 `_start` 为我们进行了一系列准备之后，这是第一个被调用的 Rust 函数
#[no_mangle]
pub extern "C" fn rust_main() -> ! {
    // 在屏幕上输出 "OK\n" ，随后进入死循环
    console_putchar(b'O');
    console_putchar(b'K');
    console_putchar(b'\n');

    loop {}
}
```

> ## **`llvm_asm`**
>
> 由于极低级别的操作和性能原因，人们可能希望直接控制 CPU。Rust 支持使用内联组件通过宏做到这一点。`llvm_asm!`
>
> ```rust
> llvm_asm!(assembly template     		//汇编段落
> 		: output operands			   //输出操作数
> 		: input operands			   //输入操作数
> 		: clobbers					  //寄存器列表
> 		: options					  //处理方法
> );
> ```
>
> **clobbers**
>
>  - Clobbers 是一个以逗号分隔的寄存器列表（该列表中还可以存放一些特殊值，用于表示一些特殊用途）
>  - 它的目的是为了告知编译器，Clobbers 列表中的寄存器会被该asm语句中的汇编代码隐性修改。
>  - 由于 Clobbers 里的寄存器会被asm语句中的汇编代码隐性修改，编译器在为 input operands 和 output operands 挑选寄存器时，就不会使用 Clobbers 里指定的寄存器，这样就避免了发生数据覆盖等逻辑错误。
>  - 通俗来讲，Clobbers 的用途就是为了告诉编译器，我这里指定的这些寄存器在该asm语句的汇编代码中用了，你在编译这条asm语句时，如果需要用到寄存器，别用我这里指定的这些，否则就都乱了。
>  - Clobbers 里的特殊值可以为 cc，用于表示该平台的 flags 寄存器会被隐性修改（比如 x86 平台的 eflags 寄存器）。
>  - Clobbers 里的特殊值也可以为 memory，用于表示某些内存数据会被隐性使用或隐性修改，所以在执行这条asm语句之前，编译器会保证所有相关的、涉及到内存的寄存器里的内容会被刷到内存中，然后再执行这条asm语句。在执行完这条asm语句之后，这些寄存器的值会再被重新load回来，然后再执行这条asm语句后面的逻辑。这样就保证了所有操作用到的数据都是最新的，是正确的。
>
> **options**
>
> options时Rust所特有的，它用于指定有关内联汇编的一些额外信息
>
> 目前的合法选项有：
>
> - `volatile`- *volatile*的作用是作为指令关键字，确保本条指令不会因编译器的优化而省略，且要求每次直接读值。
> - `alignstack`- 某些说明期望该堆栈以某种方式（即 SSE）对齐，并指定此指示编译器插入其通常的堆栈对齐代码
> - `intel`- 使用英特尔汇编语法而不是默认的AT&T。

> **global_asm**
>
> `global_asm!`宏允许程序员在函数主体范围之外编写任意汇编代码，然后将其传递给编译器.

这样，如果我们将内核镜像加载完成后，屏幕上出现了 OK ，就说明我们之前做的事情没有问题。

现在我们生成内核镜像要通过多条命令来完成，我们可以通过在 os 目录下建立一个 Makefile 来简化这一过程：

```makefile
TARGET      := riscv64gc-unknown-none-elf
MODE        := debug
KERNEL_FILE := target/$(TARGET)/$(MODE)/os
BIN_FILE    := target/$(TARGET)/$(MODE)/kernel.bin

OBJDUMP     := rust-objdump --arch-name=riscv64
OBJCOPY     := rust-objcopy --binary-architecture=riscv64

.PHONY: doc kernel build clean qemu run

# 默认 build 为输出二进制文件
build: $(BIN_FILE) 

# 通过 Rust 文件中的注释生成 os 的文档
doc:
    @cargo doc --document-private-items

# 编译 kernel
kernel:
    @cargo build

# 生成 kernel 的二进制文件
$(BIN_FILE): kernel
    @$(OBJCOPY) $(KERNEL_FILE) --strip-all -O binary $@

# 查看反汇编结果
asm:
    @$(OBJDUMP) -d $(KERNEL_FILE) | less

# 清理编译出的文件
clean:
    @cargo clean

# 运行 QEMU
qemu: build
    @qemu-system-riscv64 \
            -machine virt \
            -nographic \
            -bios default \
            -device loader,file=$(BIN_FILE),addr=0x80200000

# 一键运行
run: build qemu
```

**(注：Makefile每一个目标的下一行是用来描述实现目标所用的命令，如果遇见`Makefile:16: *** missing separator.  Stop.`则说明需要用 `Tab键` / `制表符` /  ACSII 码 `0x09` 开头，而不能用空格 ACSII 码 `0x20`)**

这里我们通过参数 `-device` 来将内核镜像加载到 QEMU 中，我们指定了内核镜像文件，并告诉 OpenSBI 最后跳转到 0x80200000 这个入口地址。

这里可以看出 `KERNEL_ELF` 保存最终可执行文件 `os` 的路径，而 `KERNEL_BIN` 保存只保留各个段数据的二进制镜像文件 `os.bin` 的路径。目标 `kernel` 直接通过 `cargo build` 以 release 模式最终可执行文件，目标 `KERNEL_BIN` 依赖于目标 `kernel`，将可执行文件通过 `rust-objcopy` 工具加上适当的配置移除所有的 header 和符号得到二进制镜像。

注意`build`部分 给出了传给 qemu 的参数。

- `-machine` 告诉 qemu 使用预设的硬件配置。在整个项目中我们将一直沿用该配置。
- `-bios` 告诉 qemu 使用我们放在 `bootloader` 目录下的预编译版本作为 bootloader。
- `-device` 则告诉 qemu 将二进制镜像加载到内存指定的位置。

最后，我们可以使用 `make run` 来用 Qemu 加载内核镜像并运行。匆匆翻过一串长长的 OpenSBI 输出，我们看到了 OK！于是历经了千辛万苦我们终于将我们的内核跑起来了！

下一节我们实现格式化输出来使得我们后续能够更加方便的通过输出来进行内核调试。

## 接口封装和代码整理

### 使用 OpenSBI 提供的服务

OpenSBI 实际上不仅起到了 bootloader 的作用，还为我们提供了一些底层系统服务供我们在编写内核时使用，以简化内核实现并提高内核跨硬件细节的能力。这层底层系统服务接口称为 SBI（Supervisor Binary Interface），是 S Mode 的 OS 和 M Mode 执行环境之间的标准接口约定。

参考 [OpenSBI 文档](https://github.com/riscv/riscv-sbi-doc/blob/master/riscv-sbi.adoc#legacy-sbi-extension-extension-ids-0x00-through-0x0f) ，我们会发现里面包含了一些以 C 函数格式给出的我们可以调用的接口。

上一节中我们的 `console_putchar` 函数类似于调用下面的接口来实现的：

```c++
void sbi_console_putchar(int ch)
```

而实际的过程是这样的：运行在 S 态的 OS 通过 ecall 发起 SBI 调用请求，RISC-V CPU 会从 S 态跳转到 M 态的 OpenSBI 固件，OpenSBI 会检查 OS 发起的 SBI 调用的编号，如果编号在 0-8 之间，则进行处理，否则交由我们自己的中断处理程序处理（暂未实现）。

执行 `ecall` 前需要指定 SBI 调用的编号，传递参数。一般而言，`a7(x17)` 为 SBI 调用编号，`a0(x10)`、`a1(x11)` 和 `a2(x12)` 寄存器为 SBI 调用参数：

对于参数比较少且是基本数据类型的时候，我们从左到右使用寄存器 `a0` 到 `a7` 就可以完成参数的传递。具体规范可参考 [RISC-V Calling Convention](https://riscv.org/wp-content/uploads/2015/01/riscv-calling.pdf)。

对于设置寄存器并执行汇编指令的代码编写，已经超出了 Rust 语言的基本描述能力。之前采用的 `global_asm!` 方式在Rust代码中插入汇编代码，还不太方便实现Rust代码与汇编代码的互操作。为有效编写 Rust代码与汇编代码的互操作，我们还有另外一种**内联汇编（Inline Assembly）**方式， 可相对简单地完成诸如把 `u8` 类型的单个字符传给 `a0` 作为输入参数的编码需求。**内联汇编（Inline Assembly）**的具体规范请参考书籍[《Rust 编程》](https://kaisery.gitbooks.io/rust-book-chinese/content/content/Inline Assembly 内联汇编.html)。

输出部分，我们将结果保存到变量 `ret` 中，限制条件 `{x10}` 告诉编译器使用寄存器 `x10`（即 `a0` 寄存器），前面的 `=` 表明汇编代码会修改该寄存器并作为最后的返回值。

输入部分，我们分别通过寄存器 `x10`、`x11`、`x12` 和 `x17`（这四个寄存器又名 `a0`、`a1`、`a2` 和 `a7`） 传入参数 `arg0`、`arg1`、`arg2` 和 `which` ，其中前三个参数分别代表接口可能所需的三个输入参数，最后一个 `which` 用来区分我们调用的是哪个接口（SBI Extension ID）。这里之所以提供三个输入参数是为了将所有接口囊括进去，对于某些接口有的输入参数是冗余的，比如 `sbi_console_putchar` 由于只需一个输入参数，它就只关心寄存器 `a0` 的值。

接着利用 `sbi_call` 函数参考 OpenSBI 文档实现对应的接口，顺带也可以把关机函数通过 SBI 接口一并实现：

```rust
//os/src/sbi.rs
//! 调用 Machine 层的操作
// 目前还不会用到全部的 SBI 调用，暂时允许未使用的变量或函数
#![allow(unused)]

/// SBI 调用
#[inline(always)]
fn sbi_call(which: usize, arg0: usize, arg1: usize, arg2: usize) -> usize {
    let ret;
    unsafe {
        llvm_asm!("ecall"
            : "={x10}" (ret)
            : "{x10}" (arg0), "{x11}" (arg1), "{x12}" (arg2), "{x17}" (which)
            : "memory"      // 如果汇编可能改变内存，则需要加入 memory 选项
            : "volatile");  // 防止编译器做激进的优化（如调换指令顺序等破坏 SBI 调用行为的优化）
    }
    ret
}

//OpenSBI的9个系统调用
const SBI_SET_TIMER: usize = 0;
const SBI_CONSOLE_PUTCHAR: usize = 1;
const SBI_CONSOLE_GETCHAR: usize = 2;
const SBI_CLEAR_IPI: usize = 3;
const SBI_SEND_IPI: usize = 4;
const SBI_REMOTE_FENCE_I: usize = 5;
const SBI_REMOTE_SFENCE_VMA: usize = 6;
const SBI_REMOTE_SFENCE_VMA_ASID: usize = 7;
const SBI_SHUTDOWN: usize = 8;

/// 向控制台输出一个字符
///
/// 需要注意我们不能直接使用 Rust 中的 char 类型
pub fn console_putchar(c: usize) {
    sbi_call(SBI_CONSOLE_PUTCHAR, c, 0, 0);
}

/// 从控制台中读取一个字符
///
/// 没有读取到字符则返回 -1
pub fn console_getchar() -> usize {
    sbi_call(SBI_CONSOLE_GETCHAR, 0, 0, 0)
}

/// 调用 SBI_SHUTDOWN 来关闭操作系统（直接退出 QEMU）
pub fn shutdown() -> ! {
    sbi_call(SBI_SHUTDOWN, 0, 0, 0);
    unreachable!()
}
```

> **函数调用与 Calling Convention**
>
> 我们知道，编译器将高级语言源代码翻译成汇编代码。对于汇编语言而言，在最简单的编程模型中，所能够利用的只有指令集中提供的指令、各通用寄存器、 CPU 的状态、内存资源。那么，在高级语言中，我们进行一次函数调用，编译器要做哪些工作利用汇编语言来实现这一功能呢？
>
> 显然并不是仅用一条指令跳转到被调用函数开头地址就行了。我们还需要考虑：
>
> - 如何传递参数？
> - 如何传递返回值？
> - 如何保证函数返回后能从我们期望的位置继续执行？
>
> 等更多事项。通常编译器按照某种规范去翻译所有的函数调用，这种规范被称为 [Calling Convention](https://en.wikipedia.org/wiki/Calling_convention) 。值得一提的是，为了确保被调用函数能正确执行，我们需要预先分配一块内存作为**调用栈** ，后面会看到调用栈在函数调用过程中极其重要。你也可以理解为什么第一章刚开始我们就要分配栈了。

现在我们比较深入的理解了 `console_putchar` 到底是怎么一回事。下面我们使用 `console_putchar` 实现格式化输出，为后面的调试提供方便。

### 实现格式化输出

只能使用 `console_putchar` 这种苍白无力的输出手段让人头皮发麻。如果我们能使用 `println!` 宏的话该有多好啊！于是我们就来实现自己的 `print!`宏和 `println!`宏！

我们将这一部分放在 `os/src/conosle.rs` 中，关于格式化输出，Rust 中提供了一个接口 `core::fmt::Write`，你需要实现函数：

```rust
fn write_str(&mut self, s: &str) -> Result
```

随后我们就可以调用如下函数（会进一步调用`write_str` 实现函数）来进行显示：

```rust
fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result
```

`write_fmt` 函数需要处理 `Arguments` 类封装的输出字符串。而我们已经有现成的 `format_args!` 宏，它可以将模式字符串和参数列表的输入转化为 `Arguments` 类，比如 `format_args!("{} {}", 1, 2)` 。

因此，我们宏的实现思路便为：

- 解析传入参数，转化为 `format_args!` 可接受的输入（事实上原封不动就行了），并通过 `format_args!` 宏得到 `Arguments` 类
- 调用 `write_fmt` 函数输出这个类

而为了调用 `write_fmt` 函数，我们必须实现 `write_str` 函数，而它可用 `console_putchar` 函数来实现。

最后，我们把整个 `print` 和 `println` 宏按照逻辑写出即可，整体逻辑的代码如下：

```rust
//os/src/console.rs
//! 实现控制台的字符输入和输出
//! 
//! # 格式化输出
//! 
//! [`core::fmt::Write`] trait 包含
//! - 需要实现的 [`write_str`] 方法
//! - 自带实现，但依赖于 [`write_str`] 的 [`write_fmt`] 方法
//! 
//! 我们声明一个类型，为其实现 [`write_str`] 方法后，就可以使用 [`write_fmt`] 来进行格式化输出
//! 
//! [`write_str`]: core::fmt::Write::write_str
//! [`write_fmt`]: core::fmt::Write::write_fmt

use crate::sbi::*;
use core::fmt::{self, Write};

/// 一个 [Zero-Sized Type]，实现 [`core::fmt::Write`] trait 来进行格式化输出
/// 
/// ZST 只可能有一个值（即为空），因此它本身就是一个单件
struct Stdout;

impl Write for Stdout {
    /// 打印一个字符串
    ///
    /// [`console_putchar`] sbi 调用每次接受一个 `usize`，但实际上会把它作为 `u8` 来打印字符。
    /// 因此，如果字符串中存在非 ASCII 字符，需要在 utf-8 编码下，对于每一个 `u8` 调用一次 [`console_putchar`]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        let mut buffer = [0u8; 4];
        for c in s.chars() {
            for code_point in c.encode_utf8(&mut buffer).as_bytes().iter() {     //使用utf-8编码模式解码
                console_putchar(*code_point as usize);
            }
        }
        Ok(())
    }
}

/// 打印由 [`core::format_args!`] 格式化后的数据
/// 
/// [`print!`] 和 [`println!`] 宏都将展开成此函数
/// 
/// [`core::format_args!`]: https://doc.rust-lang.org/nightly/core/macro.format_args.html
pub fn print(args: fmt::Arguments) {
    Stdout.write_fmt(args).unwrap();
}

/// 实现类似于标准库中的 `print!` 宏
/// 
/// 使用实现了 [`core::fmt::Write`] trait 的 [`console::Stdout`]
#[macro_export]
macro_rules! print {
    ($fmt: literal $(, $($arg: tt)+)?) => {
        $crate::console::print(format_args!($fmt $(, $($arg)+)?));  			//不加回车
    }
}

/// 实现类似于标准库中的 `println!` 宏
/// 
/// 使用实现了 [`core::fmt::Write`] trait 的 [`console::Stdout`]
#[macro_export]
macro_rules! println {
    ($fmt: literal $(, $($arg: tt)+)?) => {
        $crate::console::print(format_args!(concat!($fmt, "\n") $(, $($arg)+)?));  //自动加入回车
    }
}
```

> **use**
>
> 在作用域中增加 `use` 和路径类似于在文件系统中创建软连接（符号连接，symbolic link）。
>
> 通过 `use` 引入作用域的路径也会检查私有性，同其它路径一样。
>
> **pub use**
>
> 当使用 `use` 关键字将名称导入作用域时，在新作用域中可用的名称是私有的。如果为了让调用你编写的代码的代码能够像在自己的作用域内引用这些类型，可以结合 `pub` 和 `use`。这个技术被称为 “*重导出*（*re-exporting*）”，因为这样做将项引入作用域并同时使其可供其他代码引入自己的作用域。
>
> **嵌套路径来消除大量的 `use` 行**
>
> 当需要引入很多定义于相同包或相同模块的项时，为每一项单独列出一行会占用源码很大的空间。
>
> 我们可以使用嵌套路径将相同的项在一行中引入作用域。这么做需要指定路径的相同部分，接着是两个冒号，接着是大括号中的各自不同的路径部分
>
> ```rust
> //原来使用use
> use std::cmp::Ordering;
> use std::io;
> //嵌套路径
> use std::{cmp::Ordering, io};
> ```
>
> **通过 glob 运算符将所有的公有定义引入作用域**
>
> 如果希望将一个路径下 **所有** 公有项引入作用域，可以指定路径后跟 `*`，glob 运算符：
>
> ```rust
> use std::collections::*;
> ```
>
> 这个 `use` 语句将 `std::collections` 中定义的所有公有项引入当前作用域。使用 glob 运算符时请多加小心！Glob 会使得我们难以推导作用域中有什么名称和它们是在何处定义的。

> ### self 与Self
>
> self与Self都是rust的关键字，看着像，用途不一样
>
> self在方法**参数中**代表这个方法的接收对象，在**模块中**代表本模块的作用域
>
> Self是trait与impl**代码块中**的语法糖，用来代表当前方法的接收类型，支持泛型

### 整理 panic 处理模块

最后，我们用刚刚实现的格式化输出和关机的函数，将 `main.rs` 中处理 panic 的语义项抽取并完善到 `panic.rs` 中：

```rust
//os/src/panic.rs
//! 代替 std 库，实现 panic 和 abort 的功能

use core::panic::PanicInfo;
use crate::sbi::shutdown;

/// 打印 panic 的信息并 [`shutdown`]
///
/// ### `#[panic_handler]` 属性
/// 声明此函数是 panic 的回调
#[panic_handler]
fn panic_handler(info: &PanicInfo) -> ! {
    // `\x1b[??m` 是控制终端字符输出格式的指令，在支持的平台上可以改变文字颜色等等，这里使用红色
    // 参考：https://misc.flogisoft.com/bash/tip_colors_and_formatting
    //
    // 需要全局开启 feature(panic_info_message) 才可以调用 .message() 函数
    println!(
        "\x1b[1;31m{}:{}: '{}'\x1b[0m",
        info.location().unwrap().file(),		//打印出panic的文件
        info.location().unwrap().line(),		//打印出引发panic的行数
        info.message().unwrap()				 //打印出问题
    );
    shutdown()
}

/// 终止程序
/// 
/// 调用 [`panic_handler`]
#[no_mangle]
extern "C" fn abort() -> ! {
    panic!("abort()")
}
```

### 检验我们的成果

最后，我们可以 `os/src/main.rs` 中去掉之前写的 `console_putchar`并调用我们新写的一系列函数，并在 Rust 入口处加入一些简单的输出看一看我们的逻辑是否正确：

```rust
//os/src/main.rs
//! # 全局属性
//! - `#![no_std]`  
//!   禁用标准库
#![no_std]
//!
//! - `#![no_main]`  
//!   不使用 `main` 函数等全部 Rust-level 入口点来作为程序入口
#![no_main]
//! # 一些 unstable 的功能需要在 crate 层级声明后才可以使用
//! - `#![feature(llvm_asm)]`  
//!   内嵌汇编
#![feature(llvm_asm)]
//!
//! - `#![feature(global_asm)]`  
//!   内嵌整个汇编文件
#![feature(global_asm)]
//!
//! - `#![feature(panic_info_message)]`  
//!   panic! 时，获取其中的信息并打印
#![feature(panic_info_message)]

#[macro_use]
mod console;
mod panic;
mod sbi;

// 汇编编写的程序入口，具体见该文件
global_asm!(include_str!("entry.asm"));

/// Rust 的入口函数
///
/// 在 `_start` 为我们进行了一系列准备之后，这是第一个被调用的 Rust 函数
#[no_mangle]
pub extern "C" fn rust_main() -> ! {
    println!("Hello rCore-Tutorial!");
    panic!("end of rust_main")
}
```

> **mod**
>
> `mod` 关键字声明了模块，Rust 会在与模块同名的文件中查找模块的代码。
>
> 当文件在不同文件夹时，需要一个文件夹中有一个单独的`mod.rs`来进行封装

在命令行中输入 `make run`，我们成功看到了 `println` 宏输出的 `Hello rCore-Tutorial!` 和一行红色的 `panic: 'end of rust_main'`！

运行结果：

```
OpenSBI v0.6
   ____                    _____ ____ _____
  / __ \                  / ____|  _ \_   _|
 | |  | |_ __   ___ _ __ | (___ | |_) || |
 | |  | | '_ \ / _ \ '_ \ \___ \|  _ < | |
 | |__| | |_) |  __/ | | |____) | |_) || |_
  \____/| .__/ \___|_| |_|_____/|____/_____|
        | |
        |_|

Platform Name          : QEMU Virt Machine
Platform HART Features : RV64ACDFIMSU
Platform Max HARTs     : 8
Current Hart           : 0
Firmware Base          : 0x80000000
Firmware Size          : 120 KB
Runtime SBI Version    : 0.2

MIDELEG : 0x0000000000000222
MEDELEG : 0x000000000000b109
PMP0    : 0x0000000080000000-0x000000008001ffff (A)
PMP1    : 0x0000000000000000-0xffffffffffffffff (A,R,W,X)
Hello rCore-Tutorial!
panic: 'end of rust_main'
```

## 