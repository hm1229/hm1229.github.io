# 实验零 RV64 裸机应用

用 Rust 实现了一个最小化的内核，并通过 QEMU 中的 RustSBI 启动了我们的内核