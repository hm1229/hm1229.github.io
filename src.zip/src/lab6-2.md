# 基础知识

1. [rCore 文件系统分析](https://rcore-os.github.io/rCore_tutorial_doc/chapter9/figures/rcore_fs_analysis.pdf)
2. [xv6 文件系统分析](https://rcore-os.github.io/rCore_tutorial_doc/chapter9/figures/xv6_fs_analysis.pdf)

